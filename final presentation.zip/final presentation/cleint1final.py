import streamlit as st
import requests
import os
import json
import azure.cognitiveservices.speech as speechsdk
import uuid

# Configuration (Use environment variables for sensitive keys)
CUSTOM_VISION_ENDPOINT = "https://customcv-prediction.cognitiveservices.azure.com/customvision/v3.0/Prediction/1caa6cea-14f1-44a4-a1ab-ef88a1d18099/classify/iterations/Iteration1/image"
CUSTOM_VISION_KEY = os.getenv("CUSTOM_VISION_KEY", "4384fefde2494239a7578ab731941244")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "fe7d5bfc266345859ca22ea03e902cbe")
OPENAI_ENDPOINT = "https://openairev.openai.azure.com"
OPENAI_DEPLOYMENT_NAME = "projectp24646"
API_VERSION = "2023-03-15-preview"

SPEECH_KEY = os.getenv("SPEECH_KEY", "09a0a26996384333be6878f0707b92e5")
SPEECH_REGION = "eastus"

TRANSLATOR_KEY = os.getenv("TRANSLATOR_KEY", "a2f9273ce05449e9843bbd429e425fe1")
TRANSLATOR_ENDPOINT = "https://api.cognitive.microsofttranslator.com/"
TRANSLATOR_LOCATION = "eastus"

# Language options
LANGUAGE_OPTIONS = {
    'English': ('en', 'en-US-JennyNeural'),
    'Spanish': ('es', 'es-ES-ElviraNeural'),
    'French': ('fr', 'fr-FR-DeniseNeural'),
    'German': ('de', 'de-DE-KatjaNeural'),
    'Italian': ('it', 'it-IT-ElsaNeural'),
    'Japanese': ('ja', 'ja-JP-NanamiNeural'),
    'Chinese (Simplified)': ('zh-Hans', 'zh-CN-XiaoxiaoNeural'),
    'Arabic': ('ar', 'ar-SA-ZariyahNeural'),
    'Russian': ('ru', 'ru-RU-SvetlanaNeural'),
    'Portuguese': ('pt', 'pt-BR-FranciscaNeural')
}

# Custom Vision API Call
def get_traffic_sign_prediction(image_data):
    headers = {
        "Prediction-Key": CUSTOM_VISION_KEY,
        "Content-Type": "application/octet-stream"
    }
    
    response = requests.post(CUSTOM_VISION_ENDPOINT, headers=headers, data=image_data)
    response.raise_for_status()
    predictions = response.json()['predictions']
    return max(predictions, key=lambda x: x['probability'])

def set_custom_style():
    st.markdown("""
    <style>
    /* Main background */
    .main {
        background-color: #1e1e1e;
        padding: 20px;
        border-radius: 10px;
        color: #f1f1f1;
    }
    /* Sidebar */
    .sidebar .sidebar-content {
        background-color: #2c3e50;
        color: #ffffff;
        padding: 20px;
    }
    /* Headings */
    h1, h3, h4 {
        color: #ADD8E6;
        text-align: center;
        font-size: 3em;
        margin-bottom: 30px;
    }
    /* Button */
    .stButton > button {
        background-color: #3498db;
        color: white;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s;
    }
    .stButton > button:hover {
        background-color: #2980b9;
    }
    /* Selectbox */
    .stSelectbox {
        background-color: #3b3b3b;
        border-radius: 5px;
        color: white;
    }
    /* Checkbox */
    .stCheckbox {
        background-color: #3b3b3b;
        padding: 10px;
        border-radius: 5px;
        color: white;
    }
    /* Result Box */
    .result-box {
        background-color: #2c3e50;
        padding: 20px;
        border-radius: 10px;
        color: white;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        margin-top: 20px;
    }
    </style>
    """, unsafe_allow_html=True)

# OpenAI Call for Description
def get_sign_description(sign_name):
    headers = {
        "api-key": OPENAI_API_KEY,
        "Content-Type": "application/json"
    }
    data = {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that provides detailed descriptions of traffic signs."},
            {"role": "user", "content": f"Provide a detailed description of the traffic sign: {sign_name}. Include its purpose, typical placement, and any specific rules associated with it."}
        ],
        "max_tokens": 300
    }
    
    url = f"{OPENAI_ENDPOINT}/openai/deployments/{OPENAI_DEPLOYMENT_NAME}/chat/completions?api-version={API_VERSION}"
    
    response = requests.post(url, headers=headers, json=data)
    response.raise_for_status()
    
    return response.json()['choices'][0]['message']['content']

# Extract key points from the description
def extract_key_points(description):
    sentences = description.split('.')
    key_points = '. '.join(sentences[:3]) + '.' if len(sentences) > 2 else description
    return key_points

# Translator API Call
def translate_text(text, target_language):
    endpoint = TRANSLATOR_ENDPOINT + '/translate'
    params = {'api-version': '3.0', 'to': target_language}
    headers = {
        'Ocp-Apim-Subscription-Key': TRANSLATOR_KEY,
        'Ocp-Apim-Subscription-Region': TRANSLATOR_LOCATION,
        'Content-type': 'application/json',
        'X-ClientTraceId': str(uuid.uuid4())
    }
    body = [{'text': text}]
    response = requests.post(endpoint, params=params, headers=headers, json=body)
    response.raise_for_status()
    return response.json()[0]['translations'][0]['text']

# Text-to-Speech using Azure
def text_to_speech(text, language):
    speech_config = speechsdk.SpeechConfig(subscription=SPEECH_KEY, region=SPEECH_REGION)
    speech_config.speech_synthesis_voice_name = LANGUAGE_OPTIONS[language][1]
    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config)
    
    result = speech_synthesizer.speak_text_async(text).get()
    if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        st.success("Speech synthesis completed successfully.")
    elif result.reason == speechsdk.ResultReason.Canceled:
        cancellation_details = result.cancellation_details
        st.error(f"Speech synthesis canceled: {cancellation_details.reason}")
        if cancellation_details.reason == speechsdk.CancellationReason.Error:
            st.error(f"Error details: {cancellation_details.error_details}")

# Streamlit app interface
def main():
    set_custom_style()

    st.title("🚦 Traffic Sign Analyzer")

    st.sidebar.header("📷 Upload Image")
    uploaded_file = st.sidebar.file_uploader("Choose an image...", type=["jpg", "jpeg", "png"])

    if uploaded_file is not None:
        col1, col2 = st.columns([1, 2])
        with col1:
            st.image(uploaded_file, caption='Uploaded Image', use_column_width=True)
        
        with col2:
            with st.spinner("🔍 Analyzing image..."):
                try:
                    image_data = uploaded_file.read()
                    prediction = get_traffic_sign_prediction(image_data)
                    sign_name = prediction['tagName']
                    confidence = prediction['probability']
                    
                    st.markdown(f"""
                    <div class='result-box'>
                        <h3>Detection Result</h3>
                        <p>Detected sign: <strong>{sign_name}</strong></p>
                        <p>Confidence: <strong>{confidence:.2%}</strong></p>
                    </div>
                    """, unsafe_allow_html=True)

                    description = get_sign_description(sign_name)
                    
                    st.subheader("📝 Sign Description")
                    show_full_description = st.checkbox("Show Full Description", value=False)
                    
                    if show_full_description:
                        st.markdown(f"<div class='result-box'>{description}</div>", unsafe_allow_html=True)
                    else:
                        key_points = extract_key_points(description)
                        st.markdown(f"<div class='result-box'><strong>Key Points:</strong> {key_points}</div>", unsafe_allow_html=True)

                    st.subheader("🌐 Translation and Speech")
                    col3, col4 = st.columns(2)
                    with col3:
                        language_choice = st.selectbox("Select a language:", list(LANGUAGE_OPTIONS.keys()))
                    with col4:
                        if language_choice:
                            if st.button("🔊 Play Speech"):
                                with st.spinner("Generating speech..."):
                                    text_to_translate = description if show_full_description else key_points
                                    translated_text = translate_text(text_to_translate, LANGUAGE_OPTIONS[language_choice][0])
                                    text_to_speech(translated_text, language_choice)
                    
                    if language_choice:
                        text_to_translate = description if show_full_description else key_points
                        translated_text = translate_text(text_to_translate, LANGUAGE_OPTIONS[language_choice][0])
                        st.markdown(f"""
                        <div class='result-box'>
                            <h4>Translated Description ({language_choice}):</h4>
                            <p>{translated_text}</p>
                        </div>
                        """, unsafe_allow_html=True)

                except Exception as e:
                    st.error(f"Error: {e}")
    else:
        st.info("👆 Upload an image in the sidebar to get started!")

if __name__ == "__main__":
    main()