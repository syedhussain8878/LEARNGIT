import requests
import os

# Set your Azure Custom Vision prediction endpoint and prediction key
ENDPOINT = "https://customcv-prediction.cognitiveservices.azure.com/customvision/v3.0/Prediction/1caa6cea-14f1-44a4-a1ab-ef88a1d18099/classify/iterations/Iteration1/image"
PREDICTION_KEY = "4384fefde2494239a7578ab731941244"

# Replace this with the correct path to your image
IMAGE_PATH = r"D:\hussa\OriginalTrafficSignData\OriginalTrafficSignData\No entry\augmented_image_11018.jpg"

# Ensure the image file exists before sending the request
if not os.path.exists(IMAGE_PATH):
    print(f"Error: The image file at {IMAGE_PATH} does not exist.")
    exit(1)

# Set headers with the prediction key
headers = {
    "Prediction-Key": PREDICTION_KEY,
    "Content-Type": "application/octet-stream"  # Ensure the content type is correct
}

# Open the image file and read it in binary mode
with open(IMAGE_PATH, "rb") as image_file:
    image_data = image_file.read()

# Send the request to the Custom Vision API
response = requests.post(ENDPOINT, headers=headers, data=image_data)

# Check the response status and handle accordingly
if response.status_code == 200:
    # Extract predictions from the JSON response
    predictions = response.json().get('predictions', [])

    if predictions:
        print("Predictions:")
        # Loop through each prediction and print its tag and probability
        for prediction in predictions:
            tag_name = prediction.get('tagName', 'Unknown')
            probability = prediction.get('probability', 0.0)
            print(f"Tag: {tag_name}, Probability: {probability:.2f}")
    else:
        print("No predictions returned.")
else:
    print(f"Error {response.status_code}: {response.text}")
