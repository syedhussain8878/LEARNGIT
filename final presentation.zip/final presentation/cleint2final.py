import streamlit as st
import requests
import os
import json
import azure.cognitiveservices.speech as speechsdk
import uuid
import time

# Configuration (Use environment variables for sensitive keys)
CUSTOM_VISION_ENDPOINT = "https://customcv-prediction.cognitiveservices.azure.com/customvision/v3.0/Prediction/1caa6cea-14f1-44a4-a1ab-ef88a1d18099/classify/iterations/Iteration1/image"
CUSTOM_VISION_KEY = os.getenv("CUSTOM_VISION_KEY", "4384fefde2494239a7578ab731941244")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "fe7d5bfc266345859ca22ea03e902cbe")
OPENAI_ENDPOINT = "https://openairev.openai.azure.com"
OPENAI_DEPLOYMENT_NAME = "projectp24646"
API_VERSION = "2023-03-15-preview"

SPEECH_KEY = os.getenv("SPEECH_KEY", "09a0a26996384333be6878f0707b92e5")
SPEECH_REGION = "eastus"

TRANSLATOR_KEY = os.getenv("TRANSLATOR_KEY", "a2f9273ce05449e9843bbd429e425fe1")
TRANSLATOR_ENDPOINT = "https://api.cognitive.microsofttranslator.com/"
TRANSLATOR_LOCATION = "eastus"

# Language options
LANGUAGE_OPTIONS = {
    'English': ('en', 'en-US-JennyNeural'),
    'Spanish': ('es', 'es-ES-ElviraNeural'),
    'French': ('fr', 'fr-FR-DeniseNeural'),
    'German': ('de', 'de-DE-KatjaNeural'),
    'Italian': ('it', 'it-IT-ElsaNeural'),
    'Japanese': ('ja', 'ja-JP-NanamiNeural'),
    'Chinese (Simplified)': ('zh-Hans', 'zh-CN-XiaoxiaoNeural'),
    'Arabic': ('ar', 'ar-SA-ZariyahNeural'),
    'Russian': ('ru', 'ru-RU-SvetlanaNeural'),
    'Portuguese': ('pt', 'pt-BR-FranciscaNeural')
}

# Custom Vision API Call
def get_traffic_sign_prediction(image_data):
    headers = {
        "Prediction-Key": CUSTOM_VISION_KEY,
        "Content-Type": "application/octet-stream"
    }
    
    response = requests.post(CUSTOM_VISION_ENDPOINT, headers=headers, data=image_data)
    response.raise_for_status()
    predictions = response.json()['predictions']
    return max(predictions, key=lambda x: x['probability'])

# OpenAI Call for Description with Retry Mechanism
def get_sign_description(sign_name, retries=5):
    headers = {
        "api-key": OPENAI_API_KEY,
        "Content-Type": "application/json"
    }
    data = {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that provides detailed descriptions of traffic signs."},
            {"role": "user", "content": f"Provide a detailed description of the traffic sign: {sign_name}. Include its purpose, typical placement, and any specific rules associated with it."}
        ],
        "max_tokens": 300
    }
    
    url = f"{OPENAI_ENDPOINT}/openai/deployments/{OPENAI_DEPLOYMENT_NAME}/chat/completions?api-version={API_VERSION}"
    
    for retry in range(retries):
        try:
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            return response.json()['choices'][0]['message']['content']
        except requests.exceptions.HTTPError as err:
            if response.status_code == 429:
                wait_time = 2 ** retry  # Exponential backoff
                print(f"Rate limit exceeded. Retrying in {wait_time} seconds...")
                time.sleep(wait_time)
            else:
                raise err  # Re-raise other errors if not rate limit
    raise Exception("Failed after retries due to rate limit or other issues")

# Extract key points from the description
def extract_key_points(description):
    sentences = description.split('.')
    key_points = '. '.join(sentences[:3]) + '.' if len(sentences) > 2 else description
    return key_points

# Translator API Call
def translate_text(text, target_language):
    endpoint = TRANSLATOR_ENDPOINT + '/translate'
    params = {'api-version': '3.0', 'to': target_language}
    headers = {
        'Ocp-Apim-Subscription-Key': TRANSLATOR_KEY,
        'Ocp-Apim-Subscription-Region': TRANSLATOR_LOCATION,
        'Content-type': 'application/json',
        'X-ClientTraceId': str(uuid.uuid4())
    }
    body = [{'text': text}]
    response = requests.post(endpoint, params=params, headers=headers, json=body)
    response.raise_for_status()
    return response.json()[0]['translations'][0]['text']

# Text-to-Speech using Azure
def text_to_speech(text, language):
    speech_config = speechsdk.SpeechConfig(subscription=SPEECH_KEY, region=SPEECH_REGION)
    speech_config.speech_synthesis_voice_name = LANGUAGE_OPTIONS[language][1]
    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config)
    
    result = speech_synthesizer.speak_text_async(text).get()
    if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        st.success("Speech synthesis completed successfully.")
    elif result.reason == speechsdk.ResultReason.Canceled:
        cancellation_details = result.cancellation_details
        st.error(f"Speech synthesis canceled: {cancellation_details.reason}")
        if cancellation_details.reason == speechsdk.CancellationReason.Error:
            st.error(f"Error details: {cancellation_details.error_details}")

# Streamlit app interface
def main():
    st.title("Traffic Sign Analyzer")

    st.sidebar.header("Upload Image")
    uploaded_file = st.sidebar.file_uploader("Choose an image...", type=["jpg", "jpeg", "png"])

    if uploaded_file is not None:
        st.image(uploaded_file, caption='Uploaded Image', use_column_width=True)
        image_data = uploaded_file.read()

        with st.spinner("Analyzing image..."):
            try:
                # Get the prediction
                prediction = get_traffic_sign_prediction(image_data)
                sign_name = prediction['tagName']
                confidence = prediction['probability']
                st.write(f"Detected sign: {sign_name} (Confidence: {confidence:.2%})")

                # Get sign description
                description = get_sign_description(sign_name)
                
                # Option to show full description or key points
                show_full_description = st.checkbox("Show Full Description", value=False)
                
                if show_full_description:
                    st.write("Sign Description:", description)
                else:
                    key_points = extract_key_points(description)
                    st.write("Key Points:", key_points)

                # Language translation
                st.subheader("Translation and Speech")
                language_choice = st.selectbox("Select a language", list(LANGUAGE_OPTIONS.keys()))
                if language_choice:
                    if show_full_description:
                        text_to_translate = description
                    else:
                        text_to_translate = key_points

                    translated_text = translate_text(text_to_translate, LANGUAGE_OPTIONS[language_choice][0])
                    st.write(f"Translated Description ({language_choice}):", translated_text)

                    # Text-to-Speech
                    if st.button("Play Speech"):
                        text_to_speech(translated_text, language_choice)

            except Exception as e:
                st.error(f"Error: {e}")

if __name__ == "__main__":
    main()
