import os
import logging
from azure.storage.blob import BlobServiceClient
from azure.cognitiveservices.vision.customvision.training import CustomVisionTrainingClient
from azure.cognitiveservices.vision.customvision.training.models import ImageFileCreateEntry
from msrest.authentication import ApiKeyCredentials

# Enable logging for debugging
logging.basicConfig(level=logging.DEBUG)

# Azure Blob Storage configuration
AZURE_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=azstrai;AccountKey=Ihhgz02H0X5o/NlsYuJLND/HZ5sCwg3JHjaqTPa3vUSYCV2IdRu/LNB/lL2a3RTiXqUwXroU4Me1+AStmPRRGQ==;EndpointSuffix=core.windows.net"
CONTAINER_NAME = "trafficimages"

# Custom Vision configuration
ENDPOINT = "https://abdulai.cognitiveservices.azure.com/"
TRAINING_KEY = "a296e4bcf156427f8a3064c96f9b9ee6"
PROJECT_ID = "1caa6cea-14f1-44a4-a1ab-ef88a1d18099"

# Create BlobServiceClient
blob_service_client = BlobServiceClient.from_connection_string(AZURE_STORAGE_CONNECTION_STRING)

# Create Custom Vision Training Client
credentials = ApiKeyCredentials(in_headers={"Training-key": TRAINING_KEY})
trainer = CustomVisionTrainingClient(ENDPOINT, credentials)

def get_or_create_tag(tag_name):
    """Retrieve or create a tag in Custom Vision."""
    tags = trainer.get_tags(PROJECT_ID)
    for tag in tags:
        if tag.name == tag_name:
            return tag
    return trainer.create_tag(PROJECT_ID, tag_name)

def upload_images_to_custom_vision():
    """Upload images from Azure Blob Storage to Custom Vision with folder names as tags."""
    
    # List blobs in the container
    blobs = blob_service_client.get_container_client(CONTAINER_NAME).list_blobs()
    
    # Dictionary to hold images by tag (folder name)
    folder_images = {}
    
    for blob in blobs:
        # Extract folder name to use as the tag
        folder_name = os.path.dirname(blob.name).split('/')[-1]  # Get the last part of the path
        if not folder_name:
            logging.info(f"Skipping root-level file: {blob.name}")
            continue  # Skip if no folder name is present
        
        # Initialize the list for the tag if not already done
        if folder_name not in folder_images:
            folder_images[folder_name] = []
        
        # Download the image from Blob Storage
        blob_client = blob_service_client.get_blob_client(CONTAINER_NAME, blob.name)
        image_data = blob_client.download_blob().readall()
        
        # Append the image data to the corresponding folder
        folder_images[folder_name].append(image_data)

    # Upload images to Custom Vision
    for folder_name, images in folder_images.items():
        logging.info(f"Uploading images for tag: {folder_name}")
        
        # Get or create the tag in Custom Vision
        tag = get_or_create_tag(folder_name)

        # Upload images in batches
        batch_size = 64
        for i in range(0, len(images), batch_size):
            batch = images[i:i + batch_size]
            image_entries = [ImageFileCreateEntry(name=f"image_{i}.jpg", contents=image) for i, image in enumerate(batch)]
            
            # Upload the batch of images
            upload_result = trainer.create_images_from_files(PROJECT_ID, images=image_entries, tag_ids=[tag.id])
            
            # Handle upload errors
            if not upload_result.is_batch_successful:
                for image_result in upload_result.images:
                    if image_result.status != "OK":
                        logging.error(f"Failed to upload image {image_result.source_url} with error: {image_result.status}")

if __name__ == "__main__":
    upload_images_to_custom_vision()
